package edu.ics211.h00;

/**
 * I thought it was obvious to use java.io.*;. as the usage of FileReader was required according to the Assignment directions
 * @author Marty Joshua 
 */
import java.io.*;

/**
 * Called the class/program FileDump because the Assignment to the Homework
 * required me to call the program FileDump
 * 
 * @author Marty Joshua
 *
 */
public class FileDump {

	/**
	 * I followed the recommendation within the assignment directions where I split
	 * off each method that converted "Hello.txt" to that of one converts the file
	 * to Binary, one converts the file to Hexadecimal, and one converts the file to
	 * UTF-8
	 * 
	 * @param file
	 * @throws FileNotFoundException
	 */

	/**
	 * I thought I would stick to the safe side and use 'throws' in this case
	 * specifically for FileNotFoundException, as the Assignment page said Yet I
	 * still bothered to use a catch method for it
	 * 
	 * @param file
	 * @throws FileNotFoundException
	 */
	static void getBinary(String file) throws FileNotFoundException {
		/**
		 * Here, I attempted to use try block and a catch block, as the requirement was
		 * noted that I was supposed to catch the FileNotFoundException error in the
		 * case where the file did not exist
		 */
		try {
			/**
			 * A file reader was used in the case where I could read whatever was put into
			 * file, which if the main was looked at, the file would be from 'args[0], the
			 * command line
			 */
			FileReader fr = new FileReader(file);
			/**
			 * Now for the for loop, I just looked at the saw that it was intended to be a 5
			 * by 10 print out of the binary string conversions, hexadecimal conversions and
			 * the UTF-8 String conversions. It worked because if I tried to add more, the
			 * strings ended up printing 111111111.
			 * 
			 * Now as for the how I managed to create the conversion, I just took the hint
			 * from the actual Assignment page. How the idea where I took the value from the
			 * read method on the file reader was from the response of a forum from here:
			 * http://tutorials.jenkov.com/java-io/filereader.html I adjusted a bit to the
			 * code of the user "Jacob Jenkov" In my perspective I thought I was taking in
			 * the bytes from the read I figured out would work when I printed it, as the
			 * numbers seemed to match with the intended output from the assignment page
			 * However, I counted a 7 or less integer output rather than an 8 integer output
			 * to the string, with the first output missing 1 or more numbers from the
			 * beginning then that was actually intended there I don't know if that's
			 * supposed to happen or not
			 * 
			 */
			for (int p = 0; p < 5; p++) {
				for (int i = 0; i < 10; i++) {
					String bTs = Integer.toBinaryString(fr.read());
					/**
					 * Ok, so a little update to my previous problem where there was less integers
					 * popping up to the string So I looked at a stack flow thread here:
					 * https://stackoverflow.com/questions/35834455/converting-a-decimal-number-to-binary-in-java-not-showing-leading-zeroes
					 * and there was a response by a 'usr2564301' that printed this response: while (result.length() % 8 > 0) { 
					 * result = "0" + result; 
					 * } return result;
					 * 
					 * and that got me thinking, so I adjusted the code a bit excluding the result and just involved the printout instead
					 * and now zeroes do manage to show up before the ones, which solved the actual problem that was happening. Nice
					 */
					while (bTs.length() % 8 > 0) {
						bTs = "0" + bTs;
					}
					System.out.print(bTs + " ");
				}
				System.out.println("");
			}
			/**
			 * As for this part I just thought this is an additional method to catch the
			 * errors in the case the file does not exist, as to the assignment's
			 * requirements Ideas on the try and catch block were taken from here
			 * https://examples.javacodegeeks.com/core-java/io/fileinputstream/read-file-in-byte-array-with-fileinputstream/
			 * by Byron Kiourtzoglou, where I managed to figure how a try and catch method
			 * was used
			 */
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Now, the method I used to code the conversion to a hexadecimal string is the
	 * same as the one I used for a conversion to a binary string. I just changed
	 * the the 'Integer.toBinaryString' to 'Integer.toHexString'
	 * 
	 * @param file
	 * @throws FileNotFoundException
	 */
	static void getHex(String file) throws FileNotFoundException {
		try {

			FileReader fr = new FileReader(file);
			for (int p = 0; p < 5; p++) {
				for (int i = 0; i < 10; i++) {
					String bTh = Integer.toHexString(fr.read());
					System.out.print(bTh + " ");
				}
				System.out.println("");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This was completely different. It's strange because I kept the loop and for
	 * some reason it required the loop I previously utilized to actually work Now
	 * along side with FileReader, I utilized FileInputStream which I was inspired
	 * from the idea here
	 * https://examples.javacodegeeks.com/core-java/io/fileinputstream/read-file-in-byte-array-with-fileinputstream/
	 * by Byron Kiourtzoglou Which is where I figure in order to read and convert
	 * bytes to a file, I would have to take the bytes first before trying out what
	 * the hint suggested on the Assignments page I tried it once I figure that at
	 * bytes[] in 'new String (bytes[], "UTF-8")' is where we had to look at bytes[]
	 * first which would be done through readAllBytes, which I found when looking
	 * for methods and thought to myself "Oh boy, I hope this works" And it did for
	 * some reason. So I tried to look for a source that would confirm how it would
	 * work:
	 * https://stackoverflow.com/questions/34054655/how-to-read-bytes-from-a-file-to-a-byte-array
	 * This came to mind as the highest responder managed to bring and idea where a
	 * file can convert to bytes through the method of .readAllBytes from a file
	 * Other than that it follows the same as the other methods I coded
	 * 
	 * @param file
	 */
	static void getUTF(String file) {
		try {

			FileReader fr = new FileReader(file);
			FileInputStream fileInp = new FileInputStream(file);
			for (int p = 0; p < 5; p++) {
				for (int i = 0; i < 10; i++) {
					byte[] b = fileInp.readAllBytes();
					String bTu = new String(b, "UTF-8");
					System.out.print(bTu + " ");
				}
				System.out.println("");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws FileNotFoundException {
		/**
		 * This was the easy part, where I would simply put what the method was going to
		 * print out, and the method's parameters would just follow up with whatever is
		 * printed out in the command line and then it would print out the results of
		 * the conversions of the file depending on the method, just as the assignment
		 * required.
		 * 
		 * You might find another txt file called 'Test' on the side I was just checking
		 * if the results would differ
		 */
		System.out.println("Binary contents of Hello.txt:");
		getBinary(args[0]);
		
		System.out.println("");
		System.out.println("Hexadecimal contents Hello.txt:");
		getHex(args[0]);
		System.out.println("");
		System.out.println("UTF-8 contents Hello.txt:");
		getUTF(args[0]);

	}

}
