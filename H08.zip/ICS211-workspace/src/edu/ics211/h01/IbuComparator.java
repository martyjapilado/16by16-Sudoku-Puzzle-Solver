package edu.ics211.h01;

import java.util.Comparator;

/**
 * Here we implement a class for the sake of comparing the ibu of 2 beers.
 * @author Marty Joshua Apilado
 *
 */

public class IbuComparator implements Comparator<Beer> {

  /**
  * This is the core method to actually compare 2 beers' ibu.
  * @param firstBeer One of the parameters for the sake of comparing the Ibu of beer
  * @param secondBeer The Second parameter is the beer that is being compared to the first beer.
  * @return firstBeer.ibu - secondBeer.ibu That just returns a certain 
  *     value for the sake of comparison.
  */

  @Override
  public int compare(Beer firstBeer, Beer secondBeer) {
    // TODO Auto-generated method stub
    return firstBeer.ibu - secondBeer.ibu;
  }

}
