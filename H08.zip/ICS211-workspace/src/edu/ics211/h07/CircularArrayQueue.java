package edu.ics211.h07;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Creation of a Queue to utilize for something.
 * 
 * @author Marty Joshua Apilado
 *
 * @param <E>
 *          Goes for any object I guess
 */
public class CircularArrayQueue<E> implements Queue211<E> {

  /**
   * The head of the list.
   */
  private int front;
  /**
   * The tail of the list.
   */
  private int rear;
  /** The size of the list. **/
  private int size;
  /** This is the array to stare things in the queue. **/
  private E[] data;

  /**
   * Implementing Iterator just in case. Based off of the second ADQ Screencast by Dr. Moore's.
   * 
   * @author Marty Joshua Apilado
   *
   */
  @SuppressWarnings("unused")
  private class Iter implements Iterator<E> {
    /** Index of next element. **/
    private int index;
    /** Count of the elements accessed so far. **/
    private int count = 0;

    /**
     * Returns true if there are more elements.
     * 
     * @return Whatever is the next element
     **/
    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#hasNext()
     */
    @Override
    public boolean hasNext() {
      // TODO Auto-generated method stub
      return count < size;
    }

    /**
     * This is to go check the next iterator. Based off of the Array Queue video.
     * 
     * @return Returns the result of the next thing in the iterator.
     */
    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#next()
     */
    @Override
    public E next() {
      // TODO Auto-generated method stub
      if (!hasNext()) {
        throw new NoSuchElementException();
      }
      E result = data[index];
      index = (index + 1) % data.length;
      count++;
      return result;
    }
  }

  /**
   * Based off of code from Dr Moore's screencast. Based off of the Array Queue video. Initializes
   * variables.
   */
  @SuppressWarnings("unchecked")
  public CircularArrayQueue() {
    this.data = (E[]) new Object[8];
    this.front = 0;
    this.rear = data.length - 1;
    size = 0;
  }

  /**
   * Based off of Dr. Moore's Screencase. This adds in objects to the queue. Based off of the Array
   * Queue video.
   * 
   * @param entry
   *          - This is the item added to the queue.
   * @return true - It always works unless it doesn't, which is where I believe it becomes false...
   *         or just never runs.
   */

  public boolean add(E entry) {
    if (size == data.length) {
      reallocate();
    }
    rear = (rear + 1) % data.length;
    data[rear] = entry;
    size++;
    return true;
  }

  /**
   * Reallocates the array if adding goes over the maximum length. Based off of Dr. Moore's Screen
   * Cast. Based off of the Array Queue video.
   */
  private void reallocate() {
    // TODO Auto-generated method stub
    @SuppressWarnings("unchecked")
    E[] newData = (E[]) new Object[2 * data.length];
    int j = front;
    for (int i = 0; i < size; i++) {
      newData[i] = data[i];
      j = (j + 1) % data.length;
    }
    this.front = 0;
    rear = size - 1;
    data = newData;
  }

  /**
   * Based off of code from Dr. Moore's screencast. Based off of the Array Queue video.
   * 
   * @return return head.item - Item at the front of the queue
   */

  public E element() {
    // TODO Auto-generated method stub
    if (size == 0) {
      throw new NoSuchElementException();
    }
    return data[front];
  }

  /**
   * Based off of code from Dr Moore's screencast. Based off of the Array Queue video.
   * 
   * @param e
   *          - Element to be offered.
   * @return add(e) or false - Returns either of these based on the where if it could add the object
   *         or not.
   */
  public boolean offer(E e) {
    // TODO Auto-generated method stub
    try {
      return add(e);
    } catch (IllegalStateException ise) {
      return false;
    }
  }

  /**
   * Based off of code from Dr Moore's screencast. Removes object from front of queue. Based off of
   * the Array Queue video.
   * 
   * @return old - Whatever was removed is returned as the "old front"
   */
  public E remove() {
    // TODO Auto-generated method stub
    if (size == 0) {
      throw new NoSuchElementException();
    }
    E value = data[front];
    front = (front + 1) % data.length;
    size--;
    return value;
  }

  /**
   * Based off of code from Dr Moore's screencast. Just tells the size. Based off of the Array Queue
   * video.
   * 
   * @return size - The variable that keeps track of the number of objects in a list.
   */
  public int size() {
    // TODO Auto-generated method stub
    return size;
  }

  /**
   * Based off of code from Dr Moore's screencast. Looks at element without removing or throwing
   * error. Based off of the Array Queue video.
   * 
   * @return Either returns element or null based on if this queue has anything or not.
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.Queue211#peek()
   */
  @Override
  public E peek() {
    // TODO Auto-generated method stub
    try {
      return element();
    } catch (NoSuchElementException nse) {
      return null;
    }
  }

  /**
   * Retrieves and removes the head of the queue. Returns null if the queue is empty. Based off of
   * code from Dr Moore's screencast. Based off of the Array Queue video.
   * 
   * @return Either returns what is removed or null based on if there is anything in the queue.
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.Queue211#poll()
   */

  @Override
  public E poll() {
    // TODO Auto-generated method stub
    try {
      return remove();
    } catch (NoSuchElementException nse) {
      return null;
    }
  }

}
