package edu.ics211.h01;
/**
 * It's a digital brewery, where the liquor is made through the help of the IBrewery interface. 
 * Everything starts to make sense at this part (Hopefully)
 * @author Marty Joshua Apilado
 *
 */

public class ManoaBrewing implements IBrewery {
  private static ManoaBrewing instance;

  private ManoaBrewing() {}
  /**
   * This is for the sake of grabbing instances, possibly for more alcohol. 
   * code from h02 in assignments.
   * @return instance Returns an instance of ManoaBrewing
   */
  
  public static ManoaBrewing getInstance() {
    if (instance == null) {
      instance = new ManoaBrewing();
    }
    return instance;
  }
  
  /**
   * Now we brew beer as the assignment says.
   * @param name Is simply the name of the beer assigned
   * @param type It's the type of the beer assigned
   * @return
   */
  
  @Override
public Beer brewBeer(String name, String type) {
    // TODO Auto-generated method stub
    //Creation of if statements return null at statements that aren't supposed to be there
    if (type == "Pilsner") {
      Beer pilsner = new Pilsner(type);
      return pilsner;
    
    } else if (type == "Bohemian Pilsner") {
      Beer bohemianPilsner = new BohemianPilsner(type);
      return bohemianPilsner;
    
    } else if (type == "India Pale Ale") {
      Beer indiaPaleAle =  new IndiaPaleAle(type, type);
      return indiaPaleAle;
    } else {
      throw new IllegalArgumentException("Nothing");
    }
    
  }
  
  /**
    * Brews a Pilsner beer as the assignment says.
   * @param name Is simply the name of the beer assigned
   * @param ibu Whatever is the IBU value of the beer
   * @pram abv Whatever is the ABV value of the beer
   * @return pilsner Returns a nicely brewed pilsner
   */
  
  @Override
public Beer brewPilsner(String name, Integer ibu, Double abv) {
    // TODO Auto-generated method stub
    //Create new Pilsner Object then return that Pilsner
    Pilsner pilsner = new Pilsner(name, ibu, abv);
    return pilsner;
  }
  
  /**
   * Brews a Bohemian Pilsner beer as the assignment says.
   * @param name Is simply the name of the beer assigned
   * @param ibu  Whatever is the IBU value of the beer
   * @param abv  Whatever is the ABV value of the beer
   * @return bohemianPilsner
   */
  
  @Override
public Beer brewBohemianPilsner(String name, Integer ibu, Double abv) {
    // TODO Auto-generated method stub
    BohemianPilsner bohemianPilsner = new BohemianPilsner(name, ibu, abv);
    return bohemianPilsner;
  }
  /**
   * Brews a India Pale Ale beer as the assignment says.
   * @param name Is simply the name of the beer assigned
   * @param ibu  Whatever is the IBU value of the beer
   * @param abv  Whatever is the ABV value of the beer
   * @return indiaPaleAle
   */
  
  @Override
public Beer brewIndiaPaleAle(String name, Integer ibu, Double abv) {
    // TODO Auto-generated method stub
    IndiaPaleAle indiaPaleAle = new IndiaPaleAle(name, ibu, abv);
    return indiaPaleAle;
  }


 

}
