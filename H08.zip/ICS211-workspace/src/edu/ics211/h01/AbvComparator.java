package edu.ics211.h01; 

import java.util.Comparator;

/**
 * This is an abv Comparator used for the sake of the creation of a method to 
 * compare the abv of 2 beers.
 * @author Marty Joshua Apilado
 *
 */
public class AbvComparator implements Comparator<Beer> {

  /**
  * I use a bunch of if statements in order to compare doubles and return it as a negative or a 
  * positive.
  * to determine the comparison.
  * @param firstBeer First Beer is used for comparison of abv values with the second.
  * @param secondBeer Second Beer is used for comparison of abv values with the first.
  * @return 1,0,-1 Where 1 is used for a return result when the abv of the first beer is larger 
  *     than the second. Returns -1 Used for a return result when the abv of the first beer 
  *     is larger than the second. Returns 0 if both values are the same.
  */

  @Override
  public int compare(Beer firstBeer, Beer secondBeer) {
    // TODO Auto-generated method stub
    if (firstBeer.abv > secondBeer.abv) {
      return 1;
    }
    if (firstBeer.abv < secondBeer.abv) {
      return -1;
    }
    return 0;
  }

}
