package edu.ics211.h01;
/**
 * Set up the Beer class as it says in the assignment page.
 * @author Marty Joshua Apilado
 *
 */

public abstract class Beer implements Comparable<Beer> {
  private String name;
  private String type;
  protected int ibu;
  protected double abv;
  /**
 * Here the Beer constructor is created as it says in the document.
 * @param name which is the name of this Beer 
 * @param type which is the type of this Beer
 */
  
  public Beer(String name, String type) {
    super();
    this.name = name;
    this.type = type;
  }
  
  /**
   * Another Beer, but now with abv and ibu as I saw it in the assignment.
 * @param name which is the name of this Beer
 * @param type which is the type of this Beer
 * @param ibu which is the ibu for this Beer
 * @param abv which is the abv for this Beer
 */
  
  public Beer(String name, String type, int ibu, double abv) {
    super();
    this.name = name;
    this.type = type;
    this.ibu = ibu;
    this.abv = abv;
  }
  /**
   * Here's that compareTo method that was mentioned on the assignment and scribbled all over my 
   * notes.
   * @param other Compares Beer name with another
   * @return A comparison of Beer names
   */
  
  public int compareTo(Beer other) {
    return name.compareTo(other.name);
  }
  /**
 * Gets name of Beer.
 * @return name
 */
  
  public String getName() {
    return name;
  }
  /**
 * Purpose is to set new name.
 * @param name Sets new name
 */
  
  public void setName(String name) {
    this.name = name;
  }
  /**
 * Returns beer type.
 * @return type 
 */
  
  public String getType() {
    return type;
  }
  /**
  * Returns IBU.
  * @return ibu
  */
  
  public int getIbu() {
    return ibu;
  }
  /**
   * Returns ABV.
   * @return abv
   */
  
  public double getAbv() {
    return abv;
  }
}


