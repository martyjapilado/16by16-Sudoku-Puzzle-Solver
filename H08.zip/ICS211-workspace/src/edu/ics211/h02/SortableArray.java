package edu.ics211.h02;

import java.util.Comparator;
/**
 * Interface made for the sake of sorting different arrays.
 * @author Marty Joshua Apilado
 *
 * @param <E> Simply a generic type to use for the other classes (Array Sorter)
 */

public interface SortableArray<E> {
  /**
  * Used for the creation of the insertionSort method in Array Sorter.
  * @param data A generic data type array is used for the sake of sorting
  * @param compare A way to compare generic data types is used for sorting
  */
  void insertionSort(E[] data, Comparator<E> compare);
  /**
  * Used for the creation of the bubbleSort method in Array Sorter.
  * @param data A generic data type array is used for the sake of sorting
  * @param compare A way to compare generic data types is used for sorting
  */
  
  void bubbleSort(E[] data, Comparator<E> compare);
  
  /**
   * Used for the creation of the insertionSort method in Array Sorter.
   * @param data A generic data type array is used for the sake of sorting
   * @param compare A way to compare generic data types is used for sorting
   */
  
  void selectionSort(E[] data, Comparator<E> compare);
  /**
   * The purpose of this method applied to in ArraySorter is to track the number of swaps within 
   * an array.
   * @return swapCount Supposed to return the number of swaps done on an array
   */
  
  int getNumberOfSwaps();
  /**
   * The purpose is tom measure the number of comparisons between objects within an array.
   * @return compareCount Returns the number of Comparisons within a sort.
   */
  
  int getNumberOfComparisons();
  /**
   * The purpose of this method in the interface is to measure the runtime of a sort. 
    * @return System.nanoTime() - startTime This was used as a means to get a runtime measurement
    */
  
  double getSortTime();
}