package edu.ics211.h07;

/**
 * This is the Queue interface.
 * @author Marty Joshua Apilado
 *
 * @param <E> This goes for any object class I guess.
 */
public interface Queue211<E> {
  /**
   * Adds items to queue.
   * @param e
   *          - Item added
   * @return returns Item added
   */
  boolean add(E e);

  /**
   * Retrieves but does not remove the front of the queue.
   * 
   * @return element returns the element found in queue
   */
  E element();

  /**
   * Based off of code from Dr Moore's screencast.
   * 
   * @param e
   *          - Element to be offered.
   * @return add(e) or false - Returns either of these based on the where if it could add the object
   *         or not.
   */

  boolean offer(E e); // adds e to the end of the queue. Returns false if the queue is full.

  /**
   * Based off of code from Dr Moore's screencast. Looks at element without removing or throwing
   * error.
   * 
   * @return Either returns element or null based on if this queue has anything or not.
   */

  E peek(); // Retrieves, but doesn't remove the head of the queue. Return null if queue is empty.

  /**
   * Retrieves and removes the head of the queue. Returns null if the queue is empty. Based off of
   * code from Dr Moore's screencast.
   * 
   * @return Either returns what is removed or null based on if there is anything in the queue.
   */
  E poll(); // Retrieves and removes the head of the queue. Returns null if the queue is empty.

  /**
   * Based off of code from Dr Moore's screencast. Removes object from front of queue.
   * 
   * @return old - Whatever was removed is returned as the "old front"
   */

  E remove(); // Retrieves and removes the head of the queue. Throws NoSuchElementException if queue
  // is empty.

  /**
   * Based off of code from Dr Moore's screencast. Just tells the size.
   * 
   * @return size - The variable that keeps track of the number of objects in a list.
   */
  int size(); // Returns the size of the queue.
}
