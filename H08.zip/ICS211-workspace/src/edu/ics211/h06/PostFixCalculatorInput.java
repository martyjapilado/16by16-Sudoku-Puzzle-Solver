package edu.ics211.h06;

import java.util.Scanner;

/**
 * I made this in case the assignment required some form of input.
 * 
 * @author Marty Joshua Apilado
 *
 */
public class PostFixCalculatorInput {

  /**
   * This is to allow user input just in case. Of course, you can only run it once. If I could 
   * I would put if statements and while loops to make it so that you can input something
   * after a given operation, but this is adequate I guess.
   * @param args
   *          - I mean I could have used input commands, but I assumed Scanner would suffice for
   *          now.
   * @throws InvalidExpressionException
   *           - this is thrown similar to the case of the calculate method at the original class
   */
  public static void main(String[] args) throws InvalidExpressionException {
    // TODO Auto-generated method stub
    PostFixCalculator calculator = PostFixCalculator.getInstance();
    System.out.println("Inset input appropriate for postfix operation: ");
    Scanner scan = new Scanner(System.in);
    Number result = calculator.calculate(scan.nextLine());
    System.out.println(result);
    scan.close();
  }

}
