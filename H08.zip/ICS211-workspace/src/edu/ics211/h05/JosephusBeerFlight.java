package edu.ics211.h05;

import edu.ics211.h01.Beer;

import java.util.LinkedList;

import java.util.ListIterator;

/**
 * This is to try out CircularDoublyLinkedList through tasting beers.
 * 
 * @author Marty Joshua Apilado
 *
 */
public class JosephusBeerFlight {
  /**
   * Creating a CircularDoublyLinkedList for beers, because the assignment told me too.
   */
  private CircularDoublyLinkedList<Beer> beers;
  /**
   * A way to copy beers List.
   */
  private CircularDoublyLinkedList<Beer> beersCopy;

  /**
   * An alternative beer list but for LinkedList this time.
   */
  LinkedList<Beer> beer = new LinkedList<Beer>();

  /**
   * Creation of a JosephusBeerFlight to set up a linked list for the beers.
   * 
   * @param items
   *          Whatever beer will be on my flight
   */
  JosephusBeerFlight(Beer[] items) {
    beers = new CircularDoublyLinkedList<Beer>(items);
    beersCopy = new CircularDoublyLinkedList<Beer>(items);
  }

  /**
   * This is to taste Beers.
   * 
   * @param start
   *          - the position of where to start tasting from (according to assignment page)
   * @param step
   *          - predetermined number for counting off (according to assignment page)
   * @param isClockwise
   *          - if isClockwise is true, counting occurs in a clockwise/increasing manner. If
   *          isClockwise is not true, then counting occurs in a counter-clockwise/decreasing
   *          manner. (according to assignment page)
   * @return beer - Beers after they were tasted.
   */
  LinkedList<Beer> tasteBeers(int start, int step, boolean isClockwise) {
    ListIterator<Beer> iter = (ListIterator<Beer>) beers.iterator();
    Beer temp = null;
    if (isClockwise == true) {
      for (int i = 0; i < start; i++) {
        iter.next();
      }
    }
    if (isClockwise == false) {
      for (int i = 0; i <= start; i++) {
        iter.previous();
      }
    }

    while (beers.size() >= 0 && isClockwise == true) {
      for (int i = 0; i < step; i++) {
        temp = iter.next();
        System.out.println(" next " + temp + " at " + iter.nextIndex());
      }
      beer.add(temp);
      System.out.println(" added " + temp);
      iter.remove();
      System.out.println(" removed " + temp);
    }

    while (beer.size() >= 0 && isClockwise == false) {
      for (int i = 0; i <= step; i++) {
        temp = iter.previous();
      }
      beer.add(temp);
      iter.remove();
    }
    beers = beersCopy;
    return beer;
  }

}
