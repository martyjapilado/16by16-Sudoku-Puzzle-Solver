package edu.ics211.h01;
/**
 *Here we place cause we want different kinds of Beer. 
 * @author Marty Joshua Apilado
 *
 */

public class Pilsner extends Beer  {
  @Override
  public int compareTo(Beer arg0) {
    // TODO Auto-generated method stub
    return 0;
  }
  /**
  * So here comes the constructor that sets the ibu, abv, and name so that it may be unique as a 
  * Beer.
  * @param name This is the name of the Pilsner Beer
  * @param ibu  This is the ibu of the Pilsner Beer
  * @param abv  This is the abv of the Pilsner Beer
  * @throws IllegalArgumentException Because I thought it would fix the test
  */
  
  public Pilsner(String name, int ibu, double abv) {
  super(name, name, ibu, abv);
    // TODO Auto-generated constructor stub
    this.setName(name);
    this.abv = abv;
    this.ibu = ibu;

    if (abv > 6.0 || abv < 4.2 || ibu < 25 || ibu > 45) {
      throw new IllegalArgumentException("Values are not valid");
    }
  }
  /**
   * So this is a new constructor but it actually does set ibu and abv based on random numbers 
   * in case if someone wanted it that way.
   * @param name This the name for whatever you want on this constructor (Pilsner)
   */
  
  public Pilsner(String name) {
    super(name, name);
    this.setName(name);
    this.ibu = 25 + (int) (Math.random() * (45 - 25)) ;
    this.abv = 4.2 + (Math.random() * (6.0 - 4.2)) ;
  }



}

