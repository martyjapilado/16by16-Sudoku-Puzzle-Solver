package edu.ics211.h06;

import java.util.Stack;
import java.util.StringTokenizer;

/**
 * Here I am trying to create the post-fix calculator class. It is a singleton class so I took some
 * code from my ManoaBrewing and modified that. Also I added a bunch of System.out.println
 * statements to "keep track".
 * 
 * @author Marty Joshua Apilado
 *
 */
public class PostFixCalculator {
  /** Number that is pretty much the overall result in a calculator. **/
  Number result;
  /** Need this to create an instance of the calculator. **/
  private static PostFixCalculator instance;

  /**
   * Creation of the PostFixCalculator because it's a singleton class.
   */
  private PostFixCalculator() {
  }

  /**
   * This is for the sake of grabbing instances, possibly for more alcohol. code from h02 in
   * assignments.
   * 
   * @return instance Returns an instance of PostFixCalculator.
   */

  public static PostFixCalculator getInstance() {
    if (instance == null) {
      instance = new PostFixCalculator();
    }
    return instance;
  }

  /**
   * This is the method that is used as the basis for the postfix calculator. StringTokenizer
   * assigned as sc to evaluate expression. Each token is identified. Code based off of problem
   * from: https://stackoverflow.com/questions/12269191/postfix-calculator-java Added some fixes
   * myself to it. Some other code was inspired by lab slides.
   * 
   * @param expression
   *          - This is the string that is "inputed" into the method.
   * @return result or result.IntValue - This is whatever is left in the sack after everything else
   *         is popped. There is an if and an else statement. If there ever was a double in the
   *         input, then the original popped value, that remains a double is returned. If there was
   *         none at all then I an Integer is returned instead.
   * @throws InvalidExpressionException
   *           - Throws Exception if the string contains something that the calculator cannot input.
   */
  public Number calculate(String expression) throws InvalidExpressionException {
    /** From https://docs.oracle.com/javase/6/docs/api/java/util/StringTokenizer.html **/
    /**
     * StringTokenizer assigned as sc to evaluate expression. Each token is identified.
     */
    StringTokenizer sc = new StringTokenizer(expression);
    /** Creation of Stack, but for Numbers. **/
    Stack<Number> calculator = new Stack<Number>();
    /** n is now the number of tokens based off of sc to use at for loop. **/
    int n = sc.countTokens();
    /**
     * Ok, I needed a boolean to check if a token is ever a double to return a result as a double.
     **/
    boolean wasDouble = false;
    for (int i = 0; i < n; i++) {
      /** The token that is to be evaluated below under the if statements. **/
      String c = sc.nextToken();
      /**
       * For the case of x, y, and r: x is to be the number evaluated alongside y. r is the result
       * of the operation of x and y and is pushed to the stack.
       **/
      Number x = 0;
      Number y = 0;
      Number r = 0;
      System.out.println("Token is: " + c);
      /** If the token turns out out be an integer it's pushed **/
      if (isInteger(c)) {
        Number temp = Integer.parseInt(c);
        calculator.push(temp);
        System.out.println("Pushed " + temp);
      } else if (isDouble(c)) {
        wasDouble = true;
        Number temp = Double.parseDouble(c);
        calculator.push(temp);
        System.out.println("Pushed " + temp);
      } else if (c.equals("+")) {
        x = calculator.pop();
        y = calculator.pop();
        if (wasDouble == true) {
          r = x.doubleValue() + y.doubleValue();
          calculator.push(r);
        } else {
          r = x.intValue() + y.intValue();
          calculator.push(r);
        }
        System.out.println("Result of " + x + " + " + y + ": " + r);
      } else if (c.equals("-")) {
        x = calculator.pop();
        y = calculator.pop();
        if (wasDouble == true) {
          r = y.doubleValue() - x.doubleValue();
          calculator.push(r);
        } else {
          r = y.intValue() - x.intValue();
          calculator.push(r);
        }
        System.out.println("Result of " + x + " - " + y + ": " + r);
      } else if (c.equals("*")) {
        x = calculator.pop();
        y = calculator.pop();
        if (wasDouble == true) {
          r = x.doubleValue() * y.doubleValue();
          calculator.push(r);
        } else {
          r = x.intValue() * y.intValue();
          calculator.push(r);
        }
        System.out.println("Result of " + x + " * " + y + ": " + r);
      } else if (c.equals("/")) {
        x = calculator.pop();
        y = calculator.pop();
        if (wasDouble == true) {
          r = y.doubleValue() / x.doubleValue();
          calculator.push(r);
        } else {
          r = y.intValue() / x.intValue();
          calculator.push(r);
        }
        System.out.println("Result of " + x + " / " + y + ": " + r);
      } else {
        throw new InvalidExpressionException();
      }
    }
    result = calculator.pop();
    System.out.println("Full Result: " + result);
    if (wasDouble == true)

    {
      return result;
    } else {
      return result.intValue();
    }
  }

  /**
   * Needed to check if certain strings are numbers. From Christopher Oezbek here
   * https://stackoverflow.com/questions/10573505/checking-strings-as-valid-integers
   * 
   * @param str
   *          - This is whatever turns out to be the String token that is identified in the
   *          calculate method.
   * @return true||false - In the case of returning true, if the string qualifies to be an Int
   *         Value. In the case of returning false, if the string turns out to not be an integer
   */
  @SuppressWarnings("unused")
  public static boolean isInteger(String str) {
    try {
      int d = Integer.parseInt(str);
      return true;
    } catch (NumberFormatException nfe) {
      return false;
    }
  }

  /**
   * Needed to check if certain strings are numbers. From Michael Dunn here
   * https://coderanch.com/t/405258/java/String-IsNumeric
   * 
   * @param str
   *          - This is whatever turns out to be the String token that is identified in the
   *          calculate method.
   * @return true||false - In the case of returning true, if the string qualifies to be an double
   *         value. In the case of returning false, if the string turns out to not be an double.
   */
  public static boolean isDouble(String str) {
    try {
      @SuppressWarnings("unused")
      double d = Double.parseDouble(str);
      return true;
    } catch (NumberFormatException nfe) {
      return false;
    }
  }

}
