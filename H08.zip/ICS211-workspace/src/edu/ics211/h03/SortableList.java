package edu.ics211.h03;

import java.util.Arrays;
import java.util.Comparator;


/**
 * Here is where the methods are made for the purpose of creating a List.
 * The kind of List that is capable of being sorted.
 * Some of the code based off of page 71-73 on 'Data Structures' by Elliot B. Koffman.
 * @author Marty Joshua Apilado
 *
 * @param <E> This is any sort of generic type that will be used in the list.
 */

public class SortableList<E> implements IList211<E>,ISortableList<E> {
  /** This is what I'd think to be the "intended capacity" where this can just be 
  * used to create a value for capacity. **/
  private static final int initialCap = 10;
  /** This is how the generic array is going to be set up. **/
  E[] data;
  /** New generic array meant to switch out with previous array in case size exceed capacity. **/
  E[] data2;
  /** Set up the size of the Array List, which grows as more generic type objects are added. **/
  private int size = 0;
  /** Used to set up the maximum capacity for an array. **/
  private int capacity = 0;
  /** Counts number of swaps in a sort.**/
  int swapCount = 0;
  /** Counts number of comparisons inside of sort. **/
  int compareCount = 0;
  /**The time of when the sort begins. **/
  private long startTime = System.nanoTime();
  /**The measure of time of the entire sort. **/
  private long fullTime;
  
  /**
   * This is a constructor meant to establish the actual list when called upon.
   */
  
  @SuppressWarnings("unchecked")
  public SortableList() {
    /**Sets the starting capacity to the initial capacity **/
    capacity = initialCap;
    /** Koffman's Textbook told me everything with this statement is fine despite what my 
    * IDE says**/
    data = (E[]) new Object[capacity];
  }
  /**
 * Here we have a method that is meant to sort by means of insertions.
 * Code based off of https://www.geeksforgeeks.org/insertion-sort/   
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  
  public void insertionSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    compareCount = 0;
    swapCount = 0;
    for (int i = 1; i < size; i++) {
      E p = data[i];
      int j = i - 1;
      while (j >= 0 && compare.compare(p, data[j]) < 0) {
        data[j + 1] = data[j];
        j = j - 1;
      }
      data[j + 1] = p;
    }
    fullTime = System.nanoTime() - startTime;
  }
  /**
 * Here we have a method that is meant to sort by means of comparing and switching objects 
 *   side by side based on comparison.
 * Code from https://www.geeksforgeeks.org/bubble-sort/.
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  
  @Override
   public void bubbleSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    int n = size;
    compareCount = 0;
    swapCount = 0;
    for (int i = 0; i < n - 1; i++) {
      for (int j = 0; j < n - i - 1 ; j++) {
        this.compareCount++;
        if (compare.compare(data[j],data[j + 1]) < 0) {
          E temp;
          temp = data[j];
          data[j] = data[j + 1];
          data[j + 1] = temp;
          ++swapCount;
        }
      }
    }
    fullTime = System.nanoTime() - startTime;
  }

  /**
  * The basis of this whole code comes from 
  * Listing 8.1 within
  * 'Data Structures: Abstraction and Design Using Java' Textbook by  Elliot B. Koffman.
  *  Variation and considerations are taken on https://www.geeksforgeeks.org/selection-sort/ .
  * Inserts the selectionSort method and algorithm.
  * @param compare Parameter used so I may be able to compare Objects from the data parameter
  */
  
  /* (non-Javadoc)
 * @see edu.ics211.h03.ISortableList#selectionSort(java.util.Comparator)
 */
  @Override
  public void selectionSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    compareCount = 0;
    swapCount = 0;
    int n = size;
    for (int fill = 0; fill < n - 1;fill++) {
      int posMin = fill;
      for (int next = fill + 1; next < n ;next++) {
        this.compareCount++;
        if (compare.compare(data[next],data[posMin]) < 0) {
          posMin = next;
        }
      } 
      E temp;
      temp = data[posMin];
      data[posMin] = data[fill];
      data[fill] = temp;
      swapCount++;
    }
    fullTime = System.nanoTime() - startTime;
  }
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getNumberOfSwaps()
  */
  
  @Override
  public int getNumberOfSwaps() {
    // TODO Auto-generated method stub
    return swapCount;
  }
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getNumberOfComparisons()
  */
  
  @Override
  public int getNumberOfComparisons() {
    // TODO Auto-generated method stub
    return compareCount;
  }

  /**
  * For the purpose of looking and measuring the time of the sorts. 
  * Taken from lecture last Wednesday.
  * @return fullTime This is to get whatever is to find the measured time of a recent sort
  */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getSortTime()
  */

  @Override
  public double getSortTime() {
    // TODO Auto-generated method stub
    return fullTime;
  }
  
  /**
   * based off of 'Data Structures' Textbook by Koffman
   * Grabs whatever is within the parameters of index, just in case we want that.
   * @param index This is pretty much the position of the object in the list
   * @return data[index] simply return the object depending on the position of the list
   */
  /* (non-Javadoc)
   * @see edu.ics211.h03.IList211#get(int)
  */

  @Override
  public E get(int index) {
    // TODO Auto-generated method stub
    if (index < 0 || index > size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    return data[index];
  }

  /**
   * Sets a object based on index to an element.
   * based off of 'Data Structures' Textbook by Koffman
   * @param index index
   * @param element Whatver the element is, it ends up replacing whatever other element is there.
   * @returns temp temp is whatever the data is based off of index/position in the list.
   */
  /* (non-Javadoc)
  * @see edu.ics211.h03.IList211#set(int, java.lang.Object)
  */
  @Override
  public E set(int index, E element) {
    // TODO Auto-generated method stub
    E temp;
    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    temp = data[index];
    data[index] = element;
    return temp;
  }
  
  /**
   * Returns the number of the position that the object was from.
   * Code from https://stackoverflow.com/questions/19625257/arraylist-implementation-of-indexoft-t-method
   * @param obj Finds the object to read the object from.
   * @return i,j,-1 Returns i if null. Returns whatever is j if there is 
   *     something based off the object. Returns -1 If there's just nothing there based 
   *     off the list.
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#indexOf(java.lang.Object)
 */
  @Override
  public int indexOf(Object obj) {
    // TODO Auto-generated method stub
    for (int i = 0; i < size; i++) {
      if (obj.equals(data[i])) {
        return i;
      }
    }
    return -1;
  }

  /**
 * Returns number depending on how many objects are within the list.
 * @return size Whatever is the size is based off of the member variable here.
 */

  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#size()
 */

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return size;
  }

  /**
   * Adds a whatever value to the end of the Array list.
   * Based off of code from the 'Data Structures' Textbook by Elliot B. Wolfgang .
   * @param e This would be whatever generic type value that is added to the end of the list
   * @return true Because nothing else would suffice.
   */

  @Override
  public boolean add(E e) {
    // TODO Auto-generated method stub
    if (size == capacity) {
      reallocate();
    }
    data[size] = e;
    size++;
    return true;
  }
  /**
   * Add method but can now add it to the middle of the list rather than the last availabe
   * position.
   * Code based off of 'Data Structures' Textbook by Elliot B. Wolfgang' pg. 73
   * @param element Element that is going to be inserted to the code
   * @param index Index is the position that the object will be added to
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#add(int, java.lang.Object)
 */
  
  @Override
  public void add(int index, E element) {
    // TODO Auto-generated method stub
    while (index < 0 || index >= size) {
      reallocate();
    }
    if (size == capacity) {
      reallocate();
    }
    for (int i = size; i > index; i--) {
      data[i] = data[i - 1];
    }
    data[index] = element;
    size++;
  }
 
  /**
 * This was taken from 'Data Structures' Textbook by Elliot B. Wolfgang' pg. 73
 * when I wanted an efficient way to actually copy over an array to a newer one 
 * when adding and increasing the capacity of an array.
 */
  
  public void reallocate() {
    capacity = 2 * capacity;
    data = Arrays.copyOf(data, capacity);
  }

  /**
   * Removes whatever object is in the position based off of the index.
   * @param index This determines the position of the object to remove.
   * @return temp Simply a return value that is used 
   *     (mostly I see it as a placeholder to give of
   *     what I want to remove)
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#remove(int)
 */
  @Override
  public E remove(int index) {
    // TODO Auto-generated method stub
    /** Create a temporary generic type object variable to store whatever inside of it.**/
    E temp;
    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    temp = data[index];
    for (int i = index + 1; i < size; i++) {
      data[i - 1] = data[i];
    }
    size--;
    return temp;
  }

}
