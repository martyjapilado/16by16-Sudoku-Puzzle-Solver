package edu.ics211.h07;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Tests my own CircularArrayQueue methods.
 * @author Marty Joshua Apilado
 *
 */
public class CircularArrayQueueStudentTest {

  /**
   * Tests if there would be an existence of a 
   * Queue when established, and if it's done so
   * correctly.
   */
  @Test
  public void testCircularArrayQueue() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    assertTrue(numQueue.poll() == null);
    assertTrue(numQueue.size() == 0);
    assertTrue(numQueue.add(2) == true);
  }

  /**
   * Tests add, tests the reallocate by reaching the point where it does
   * this, point being where it surpasses size 8.
   */
  @Test
  public void testAdd() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    for (int i = 0; i < 8; i++) {
      numQueue.add(1);
    }
    // The point where it reallocates
    numQueue.add(2);
    assertTrue(numQueue.size() == 9);
    assertTrue(numQueue.poll() == 1);

  }

  /**
   * Checks to see if an exception is thrown, then checks if it returns 
   * elements correctly.
   */
  @Test
  public void testElement() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    try {
      numQueue.element();
    } catch (NoSuchElementException nse) {
      //Supposed to happen
    }
    numQueue.add(2);
    assertTrue(numQueue.element() == 2);
  }

  /**
   * This is the same case with add, but with offer instead.
   */
  @Test
  public void testOffer() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    for (int i = 0; i < 8; i++) {
      numQueue.offer(1);
    }

    // The point where it reallocates
    numQueue.offer(2);
    assertTrue(numQueue.peek() == 1);
    assertTrue(numQueue.size() == 9);
  }

  /**
   * Tests remove method by creating a queue with items, 
   * then removing them and making sure it's first in, first out,
   * then check if the remove function does read that 
   * there is nothing in the queue if there is nothing.
   */
  @Test
  public void testRemove() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    for (int i = 0; i < 8; i++) {
      numQueue.add(1);
    }
    // The point where it reallocates
    numQueue.add(2);
    int numSize = 8;
    for (int i = 0; i < 8; i++) {
      assertTrue(numQueue.remove() == 1);
      assertTrue(numQueue.size() == numSize);
      numSize--;
    }
    assertTrue(numQueue.remove() == 2);
    assertTrue(numQueue.poll() == null);
    try {
      numQueue.remove();
      fail("Supposed to throw exception");
    } catch (NoSuchElementException nse) {
      //Supposed to happen
    }
  }

  /**
   * Tests Size in some way, simple as that .
   */
  @Test
  public void testSize() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    for (int i = 0; i < 8; i++) {
      numQueue.add(1);
    }
    // The point where it reallocates
    numQueue.add(2);
    assertTrue(numQueue.size() == 9);
  }

  /**
   * Same case as element but checks null instead of an exception.
   */
  @Test
  public void testPeek() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    assertTrue(numQueue.peek() == null);
    numQueue.add(2);
    assertTrue(numQueue.peek() == 2);
  }

  /**
   * Same case as the removal but checks to see if poll returns null instead of 
   * and exception.
   */
  @Test
  public void testPoll() {
    CircularArrayQueue<Integer> numQueue = new CircularArrayQueue<Integer>();
    int numSize = 7;
    for (int i = 0; i < 8; i++) {
      numQueue.add(1);
    }
    for (int i = 0; i < 8; i++) {
      assertTrue(numQueue.poll() == 1);
      assertTrue(numQueue.size() == numSize);
      numSize--;
    }
    numQueue.add(2);
    assertTrue(numQueue.remove() == 2);
    assertTrue(numQueue.poll() == null);
    // The point where it reallocates
    
  }

}
