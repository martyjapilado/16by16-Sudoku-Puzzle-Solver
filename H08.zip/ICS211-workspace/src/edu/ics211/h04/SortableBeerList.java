package edu.ics211.h04;

import edu.ics211.h01.Beer;
import java.util.Comparator;


/**
 * This is like the Beer
 * Admittedly the code for this is the same as SortableList with a few minor changes
 * , namely changing E to Beer.
 * Got help from Brandon (the TA) in the case of Beer paramaters.
 * 
 * @author Marty Joshua Apilado
 *
   */

public class SortableBeerList implements IList211<Beer> {

  /** This said on the assignment page to put this here, and I assume the reason 
 * for that is for this whole class to work around.**/
  private SortableList<Beer> beers = new SortableList<Beer>();
  
  /** This is how the generic array is going to be set up. **/
  Beer[] data;
  /** New generic array meant to switch out with previous array in case size exceed capacity. **/
  Beer[] data2;
  /** Counts number of swaps in a sort.**/
  int swapCount = 0;
  /** Counts number of comparisons inside of sort. **/
  int compareCount = 0;
  /** Comparator to use later. **/
  Comparator<Beer> comp;
  
  /**
   * This is the constructor meant to take in the beers variable above.
   * Got help from Colby.
 * @param e This is a Comparator meant to decide the order of the beers.
 */
  
  SortableBeerList(Comparator<Beer> compare) {
    /** Comparator to use later. **/
    this.comp = compare;
    beers = new SortableList<Beer>();
  }



  
  /**
 * So this simply returns the number of swaps in a sorting algorithm.
 * 
 * @return swapCount this simply returns the int for compare count that was
 *         gathered during a sort.
 */
  
  public int getNumberOfSwaps() {
    // TODO Auto-generated method stub
    return beers.getNumberOfSwaps();
  }
  
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getNumberOfComparisons()
  */
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  public int getNumberOfComparisons() {
    // TODO Auto-generated method stub
    return beers.getNumberOfComparisons();
  }


  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getSortTime()
  */
  /**
  * For the purpose of looking and measuring the time of the sorts. 
  * Taken from lecture last Wednesday.
  * @return fullTime This is to get whatever is to find the measured time of a recent sort
  */
  public double getSortTime() {
    // TODO Auto-generated method stub
    return beers.getSortTime();
  }
  
  /**
   * Grabs whatever is within the parameters of index, just in case we want that.
   * @param index This is pretty much the position of the object in the list
   * @return data[index] simply return the object depending on the position of the list
   */
  /* (non-Javadoc)
   * @see edu.ics211.h03.IList211#get(int)
  */

  @Override
  public Beer get(int index) {
    return beers.get(index);
  }

  /**
   * Sets a object based on index to an element.
   * based off of 'Data Structures' Textbook by Koffman
   * @param index index
   * @param element Whatver the element is, it ends up replacing whatever other element is there.
   * @returns temp temp is whatever the data is based off of index/position in the list.
   */
  /* (non-Javadoc)
  * @see edu.ics211.h03.IList211#set(int, java.lang.Object)
  */
  @Override
  public Beer set(int index, Beer element) {
    // TODO Auto-generated method stub
    return beers.set(index, element);
  }
  
  /**
   * Takes whatever number based on the position of obj.
   * Taken from https://stackoverflow.com/questions/19625257/arraylist-implementation-of-indexoft-t-method.
   * @param obj The object that is detected
   * @return -1 returns -1 if the object can't be found in list
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#indexOf(java.lang.Object)
 */
  @Override
  public int indexOf(Object obj) {
    // TODO Auto-generated method stub
    return beers.indexOf(obj);
  }

  /**
 * Returns number depending on how many objects are within the list.
 * @return size returns whatever the size is depending
 */

  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#size()
 */

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return beers.size();
  }

  /**
   * Adds a whatever value to the end of the Array list.
   * Based off of code from the 'Data Structures' Textbook by Elliot B. Wolfgang .
   * @param e This would be whatever generic type value that is added to the end of the list
   * @return So I was thinking that I can't place the sorting algorithm after a return,
   *     but I can place it if I did put the add but didn't return it and instead tried return true.
   */

  @Override
  public boolean add(Beer e) {
    // TODO Auto-generated method stub
    beers.add(e);
    beers.insertionSort(comp);
    return true;
  }
  
  /**
   * Adds object based off obeers.bubbleSort(compare);f the position (index).
   * Code based off of 'Data Structures' Textbook by Elliot B. Wolfgang' pg. 73
   * @param element Is the element that will be added
   * @param index The index is the position that the element will be added at
   *
   * @see edu.ics211.h03.SortableList#add(int, java.lang.Object)
  */
  
  public void add(int index, Beer element) {
    beers.add(index, element);
    beers.insertionSort(comp);
  }

  /**
   * Removes the object based off of the index/position.
   * @param index The position of the object that will be removed.
   * @return returnValue
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#remove(int)
 */
  @Override
  public Beer remove(int index) {
    // TODO Auto-generated method stub
    return beers.remove(index);
  }
}
