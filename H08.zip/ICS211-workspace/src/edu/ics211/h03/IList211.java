package edu.ics211.h03;

/**
 * Interface for creating list.
 * From ICS assignment page.
 * @author Marty Joshua Apilado
 *
 * @param <E> Pretty much anything, makes interface accessible.
 */
public interface IList211<E> {
  /**
   * Grabs whatever is within the parameters of index, just in case we want that.
   * @param index This is pretty much the position of the object in the list
   * @return data[index] simply return the object depending on the position of the list
   */
  E get(int index);
  /**
   * Sets a object based on index to an element.
   * based off of 'Data Structures' Textbook by Koffman
   * @param index index
   * @param element Whatver the element is, it ends up replacing whatever other element is there.
   * @return temp temp is whatever the data is based off of index/position in the list.
   */
  
  E set(int index, E element);
  /**
   * Returns the number of the position that the object was from.
   * Code from https://stackoverflow.com/questions/19625257/arraylist-implementation-of-indexoft-t-method
   * @param obj Finds the object to read the object from.
   * @return i,j,-1 Returns i if null. Returns whatever is j if there is 
   *     something based off the object. Returns -1 If there's just nothing there based 
   *     off the list.
   */
  
  int indexOf(Object obj);
  /**
 * Returns number depending on how many objects are within the list.
 * @return size Whatever is the size is based off of the member variable here.
 */
  
  int size();
  
  /**
   * Adds a whatever value to the end of the Array list.
   * Based off of code from the 'Data Structures' Textbook by Elliot B. Wolfgang .
   * @param e This would be whatever generic type value that is added to the end of the list
   * @return true Because nothing else would suffice.
   */
  
  boolean add(E e);
  /**
   * Add method but can now add it to the middle of the list rather than the last availabe
   * position.
   * Code based off of 'Data Structures' Textbook by Elliot B. Wolfgang' pg. 73
   * @param element Element that is going to be inserted to the code
   * @param index Index is the position that the object will be added to
   */
  
  void add(int index, E element);
  
  /**
   * Removes whatever object is in the position based off of the index.
   * @param index This determines the position of the object to remove.
   * @return temp Simply a return value that is used 
   *     (mostly I see it as a placeholder to give of
   *     what I want to remove)
   */
  
  E remove(int index);
  
}

