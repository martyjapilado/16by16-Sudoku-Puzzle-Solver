package edu.ics211.h01;
/**
 * Creation of the Bohemian Pilsner class as it says on the assignment.
 * @author Marty Joshua
 *
 */

public class BohemianPilsner extends Pilsner {
  /**
 * Creation of Bohemian Pilsner, just like the other Pilsner.
 * @param name Name for this Pilsner
 * @param ibu  IBU for this Pilsner
 * @param abv  ABV for this Pilsner
 */

  public BohemianPilsner(String name, int ibu, double abv) {
  super(name, ibu, abv);
    // TODO Auto-generated constructor stub
    this.setName(name);
    
    this.abv = abv;
    this.ibu = ibu;
    if (abv > 5.4 || abv < 4.2 || ibu < 35 || ibu > 45) {
      throw new IllegalArgumentException("Values are not valid");
    }
  }
  /**
 * Some people want a different kind of Bohemeian Pilsner.
 * This is that Bohemian Pilsner. 
 * @param name This is the name for the BohemianPilsner
 */
  
  public BohemianPilsner(String name) {
    super(name);
    this.setName(name);
    this.ibu = (int)(Math.random() * (45 - 35)) + 35;
    this.abv = (Math.random() * (5.4 - 4.2)) + 4.2;
  }

}
