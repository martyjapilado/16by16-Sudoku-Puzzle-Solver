package edu.ics211.h06;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * So this is a JUnit Test created to test out my PostFixCalculator class.
 * 
 * @author Marty Joshua Apilado
 *
 */
public class PostFixCalculatorStudentTest {

  /**
   * Tests by running through certain operations, first with integer, and the another with doubles.
   * Try and catch methods are there to see if it works as intended. I also threw another test
   * that's meant to throw the error just in case.
   */
  @Test
  public void testCalculate() {
    PostFixCalculator c = PostFixCalculator.getInstance();
    /** This bit was from the other test by Dr. Moore, just in case. **/
    assertNotNull(c);
    /** Basic testing of integer operation **/
    try {
      Number ans = c.calculate("1 3 4 * + 4 8 + / ");
      /** Bits like these also came from Dr. Moore's test case **/
      assertTrue("Supposed to be Integer", ans instanceof Integer);
      assertEquals("Should be ", Integer.valueOf(1), ans);
    } catch (InvalidExpressionException iee) {
      fail("No exceptions please");
    }
    /** Checks to see if a double can be operated on and returned. **/
    try {
      Number ans = c.calculate("1 3 4.0 - + 10.2 3.8 + / ");
      assertTrue("Supposed to be Double", ans instanceof Double);
      assertEquals("Should be ", Double.valueOf(0.0), ans);
    } catch (InvalidExpressionException iee) {
      fail("No exceptions please");
    }
    try {
      @SuppressWarnings("unused")
      Number ans = c.calculate("Not gonna work ");
      fail("Should have thrown exception");
    } catch (InvalidExpressionException ese) {
      // Supposed to happen.
    }

  }

}
