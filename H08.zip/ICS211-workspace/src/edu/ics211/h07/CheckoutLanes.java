package edu.ics211.h07;

import java.util.ArrayList;
import java.util.List;

/**
 * This is used to simulate lanes that are checked out of. 
 * Worked with: Colby.
 * @author Marty Joshua Apilado
 *
 */
public class CheckoutLanes {
  CircularArrayQueue<Shopper>[] express;
  CircularArrayQueue<Shopper>[] regular;
  Shopper shopper;
  int numShoppers = 0;

  /**
   * This is a way to "place" checkout lines to simulate.
   * @param numExpress - This represents the number of Express lanes that are placed.
   * @param numRegular - This represents the number of regular lanes that are added.
   */

  @SuppressWarnings("unchecked")
  public CheckoutLanes(int numExpress, int numRegular) {
    express = new CircularArrayQueue[numExpress];
    regular = new CircularArrayQueue[numRegular];
    for (int i = 0; i < numRegular; i++) {
      System.out.println("Adding regular lane");
      regular[i] = new CircularArrayQueue<Shopper>();
    }
    for (int i = 0; i < numExpress; i++) {
      System.out.println("Adding express lane");
      express[i] = new CircularArrayQueue<Shopper>();
    }
  }

  /**
   * Adds shoppers to corresponding lane numbers.
   * Note: I'm wondering how this is supposed to work in terms of assigning a shopper to either the
   * Express or Regular. It starts with express however I don't know how the actually do the for
   * loop that recognizes the regular lanes.
   * Note: I actually managed to fix this. Turns out it was at the constructor.
   * 
   * @param laneNumber - The lane Number that the shopper is assigned to.
   * @param shopper - This is the shopper added to the corresponding laneNumber
   */

  public void enterLane(int laneNumber, Shopper shopper) {
    int countLanes = 0;
    System.out.println("There is " + express.length + " Express lanes.");
    System.out.println("There is " + regular.length + " regular lanes.");
    try {
      for (int i = 0; i < express.length; i++) {
        System.out.println("Currently in " + i + " express.");
        System.out.println("Looking for lane " + laneNumber);
        if (laneNumber == countLanes) {
          System.out.println("Adding shopper" + " to Express " + i);
          express[i].offer(shopper);
          this.numShoppers++;
        } else {
          System.out.println("Skimming... ");
          countLanes++;
        }

      }
      if (countLanes >= express.length) {
        for (int i = 0; i < regular.length; i++) {
          if (countLanes == laneNumber) {
            System.out.println("Adding shopper to Regular " + (laneNumber));
            regular[i].add(shopper);
            this.numShoppers++;
          }
          System.out.println("Skimming... ");
          countLanes++;
        }
      }
    } catch (IndexOutOfBoundsException iobe) {
      throw new IndexOutOfBoundsException();
    }
  }

  /**
   * This simulates the checkout by going by each lane starting with the express and then the
   * regular, with the move to regular lane done just in case.
   * 
   * @return checkout - As in returns the list of people who managed to checkout.
   */

  public List<Shopper> simulateCheckout() {
    List<Shopper> checkout = new ArrayList<Shopper>();
    System.out.println("Number of shoppers: " + this.numShoppers);
    while (this.numShoppers != 0) {
      int countLanes = 0;
      for (int i = 0; i < regular.length; i++) {
        while (regular[i].size() != 0) {
          System.out.println("Regular Lane " + (countLanes + express.length) + " shopper had "
              + regular[i].peek().getNumberOfItems() + " items");
          checkout.add(regular[i].remove());
          this.numShoppers--;
        }
        countLanes++;
      }

      for (int i = 0; i < express.length; i++) {
        while (express.length != 0 && express[i].peek() != null
            && express[i].element().getNumberOfItems() > 10) {
          System.out.println("Express lane shopper with " + express[i].peek().getNumberOfItems()
              + " items moved to lane " + (express.length + 1));
          regular[regular.length - 1].offer(express[i].remove());
        }

      }
      countLanes = 0;
      for (int i = 0; i < express.length; i++) {
        if (express[i].peek() != null) {
          System.out.println("Express Lane " + countLanes + " shopper had "
              + express[i].peek().getNumberOfItems() + " items");
          checkout.add(express[i].remove());
          this.numShoppers--;
        }
        countLanes++;
      }
    }

    return checkout;

  }
}
