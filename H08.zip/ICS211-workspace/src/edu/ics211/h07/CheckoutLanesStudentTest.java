package edu.ics211.h07;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

/**
 * Tests the CheckoutLanes' methods myself.
 * @author Marty Joshua Apilado
 *
 */
public class CheckoutLanesStudentTest {

  /**
   * Tests out to see if there is ever an instance of checkout lanes.
   */
  @Test
  public void testCheckoutLanes() {
    CheckoutLanes lanes = new CheckoutLanes(1, 1);
    assertTrue(lanes.express[0].size() == 0);
    try {
      lanes.express[1].element();
    } catch (IndexOutOfBoundsException iobe) {
      //Supposed to happen
    }
    try {
      lanes.regular[1].element();
    } catch (IndexOutOfBoundsException iobe) {
      //Supposed to happen
    }
  }

  /**
   * Although I can already know if the input actually in the test provided, here I am simply
   * testing for an input that turns out to be invalid, in this case lane 6.
   */
  @Test
  public void testEnterLane() {
    CheckoutLanes lanes = new CheckoutLanes(2, 3);
    try {
      lanes.enterLane(6, new Shopper(10));

    } catch (IndexOutOfBoundsException iobe) {
      // Supposed to happen
    }
    lanes.enterLane(1, new Shopper(2));
    assertTrue(lanes.numShoppers == 1);
  }

  /**
   * Test out the simulaion of a checkout.
   */
  @Test
  public void testSimulateCheckout() {
    CheckoutLanes lanes = new CheckoutLanes(2, 3);
    try {
      lanes.enterLane(6, new Shopper(10));

    } catch (IndexOutOfBoundsException iobe) {
      // Supposed to happen
    }
    lanes.enterLane(0, new Shopper(10));
    lanes.enterLane(1, new Shopper(11));
    lanes.enterLane(2, new Shopper(20));
    lanes.enterLane(3, new Shopper(15));
    List<Shopper> shoppers = lanes.simulateCheckout();
    assertTrue(shoppers.get(0).getNumberOfItems() == 20);
    assertTrue(shoppers.get(1).getNumberOfItems() == 15);
    assertTrue(shoppers.get(2).getNumberOfItems() == 10);
    assertTrue(shoppers.get(3).getNumberOfItems() == 10);
  }

}
