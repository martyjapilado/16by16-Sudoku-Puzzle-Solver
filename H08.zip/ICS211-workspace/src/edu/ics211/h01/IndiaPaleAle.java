package edu.ics211.h01;
/**
 * For the reason that maybe somebody wants some India Pale Ale.
 * @author Marty Joshua Apilado
 *
 */

public class IndiaPaleAle extends Beer {

  @Override
  public int compareTo(Beer arg0) {
    // TODO Auto-generated method stub
    return 0;
  }
  /**
  * This is like the Pilsner Beer class, in which I just copied and pasted 
  * the same idea from that class.
  * @param name This is the name for the IndiaPaleAle
  * @param ibu This is the ibu for the IndiaPaleAle 
  * @param abv This is the abv for the IndiaPaleAle
  */
  
  public IndiaPaleAle(String name, int ibu, double abv) {
  super(name, name, ibu, abv);
    // TODO Auto-generated constructor stub
    this.setName(name);
    this.abv = abv;
    this.ibu = ibu;
    if (abv > 10.0 || abv < 5.0 || ibu < 40 || ibu > 100) {
      throw new IllegalArgumentException("Values are not valid and out of range");
    }
  }
  /**
   * This is the same as above because we want some kind of different alcohol ya know.
   * @param name This is the name for the IndiaPaleAle
   * @param type This is the type for the IndiaPaleAle
   */
  
  public IndiaPaleAle(String name, String type)  {
    super(name, type);
    // TODO Auto-generated constructor stub
    this.setName(name);
    this.ibu = (int)(Math.random() * (100 - 40)) + 40;
    this.abv = (Math.random() * 5.0) + 5.0;
  }




}
