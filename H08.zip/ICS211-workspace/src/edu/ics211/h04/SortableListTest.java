package edu.ics211.h04;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Comparator;

import org.junit.Before;
import org.junit.Test;

/**
 * Here's to test out the Doubly Linked List Sortable List.
 * @author Marty Joshua Apilado
 *
 */
public class SortableListTest {
  SortableList<Integer> bunchOfNum = new SortableList<Integer>();
  SortableList<Integer> otherBunchOfNum = new SortableList<Integer>();
  /**
   * Tests out SortableList method through initializing a bunch of variables we use throughout the
   * test. To note most of these sort methods come from H02 assignment test.
   */
  private Comparator<Integer> testSort;

  /**
   * Simply initializes a list of numbers to test out.
   * 
   */
  @Before
  public void initialize() {
    for (int i = 15; i >= 0; i--) {
      bunchOfNum.add(i);
    }
  }

  /**
   * Tests out insertion sort method within the SortablList with the isSorted method.
   * Admittedly gives a Null Pointer Exception for the reason I suspect is that the Comparator
   * itself returns null.
   */
  @Test
  public void testInsertionSort() {
    bunchOfNum.insertionSort(testSort);
    assertTrue("Not Sorted", isSorted(bunchOfNum, testSort));
  }

  /**
   * Tests out bubble sort method within the SortablList with the isSorted method.
   *    * Admittedly gives a Null Pointer Exception for the reason I suspect is that the Comparator
   * itself returns null.
   */
  @Test
  public void testBubbleSort() {
    bunchOfNum.bubbleSort(testSort);
    assertTrue("Not Sorted", isSorted(bunchOfNum, testSort));
  }

  /**
   * Tests out selection sort method within the SortablList with the isSorted method.
   * Admittedly gives a Null Pointer Exception for the reason I suspect is that the Comparator
   * itself returns null.
   */
  @Test
  public void testSelectionSort() {
    bunchOfNum.selectionSort(testSort);
    assertTrue("Not Sorted", isSorted(bunchOfNum, testSort));
  }
  
  /**
   * Note: I didn't test getNumberofSwaps/getNumberOfSorts/testGetSortTime
   *  because I wanted my test to 
   * focus solely on the List methods and sorting algorithms.
   * As for testGet, the point is that at a certain point that
   */
  
  @Test
  public void testGet() {
    assertTrue("Didn't Get", bunchOfNum.get(0).equals(15));
  }

  /**
 * The way this works is it's supposed to take the 2nd position (because 0 then 1) and place 2 
 * there so we check if 1 is equal to 2.
 */
  @Test
  public void testSet() {
    bunchOfNum.set(1, 2);
    assertTrue("Wrong set", bunchOfNum.get(1).equals(2));
  }

  /**
  * Tests out the IndexOf method in SortableLists.
  * It is done by
  */
  @Test
  public void testIndexOf() {
    assertEquals("Can't find", bunchOfNum.indexOf(3), 12);
  }
  /**
   * Simple test, just read size and see if the size is the same as the one I 
   * originally initiated.
   */

  @Test
  public void testSize() {
    assertEquals("Wrong size want 15", bunchOfNum.size(), 16);
  }

  /**
   * I add in another integer value and see if something is actually added.
   */
  @Test
  public void testAddE() {
    bunchOfNum.add(89);
    assertEquals("Wrong size want 16", bunchOfNum.size(), 17);
  }

  /**
 * The way this works is that we add 88 at the 16th position, then check 
 * if the size has increased at all as a result, then check if
 * 88 was placed correctly at 16.
 * error catch based off of Doctor Moore's SortableBeerList
 */
  @Test
  public void testAddIntE() {
    bunchOfNum.add(0,-1);
    assertEquals("Wrong size want 17", bunchOfNum.size(), 17);
    assertTrue("Wrong Get", bunchOfNum.get(0).equals(-1));
  }

  /**
 * Based off of SortableBeerListTest test.
 * Just attempt to see if the error in the code works as intended
 * then try the remove and see if the list matches what I intended.
 */
  @Test
  public void testRemove() {
    try {
      bunchOfNum.remove(-1);
      fail("Should throw exception");
    } catch (Exception e) {
     //
    }
    assertEquals("Wrong size want 15", bunchOfNum.size(), 16);
    bunchOfNum.remove(0);
    assertEquals("Wrong size want 14", bunchOfNum.size(), 15);
  }

  private boolean isSorted(SortableList<Integer> data, Comparator<Integer> comp) {
    for (int i = 0; i < data.size() - 1; i++) {
      if (comp.compare(data.get(i), data.get(i + 1)) > 0) {
        return false;
      }
    }
    return true;
  }

  

}
