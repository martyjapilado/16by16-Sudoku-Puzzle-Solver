package edu.ics211.h02;

import java.util.Comparator;
/**
 * The purpose of this class is to create a class of Array Sorters, those being insertion, 
 * bubble and selection sorting methods.
 * Also worked with Davin
 * @author Marty Joshua Apilado
 * @param <E>
 *
 */

public class ArraySorter<E> implements SortableArray<E> {
  int swapCount = 0;
  int compareCount = 0;
  /**
  * Based on code found from https://www.geeksforgeeks.org/insertion-sort/    .
  * @param compare Parameter used so I may be able to compare Objects from the data parameter
  * @param data This parameter is used so I may call up Objects to be sorted
  */

  /* (non-Javadoc)
 * @see edu.ics211.h02.SortableArray#insertionSort(java.lang.Object[], java.util.Comparator)
 */
  @Override
  public void insertionSort(E[] data, Comparator<E> compare) {
    swapCount = 0;
    compareCount = 0;
    for (int i = 1; i < data.length;++i) {
      E p = data[i];
      int j = i - 1;
      while (j >= 0 && compare.compare(p, data[j]) < 0) {
        swapCount++;
        data[j + 1] = data[j];
        j = j - 1;
      }
      data[j + 1] = p;
      compareCount++;
    }
  }
  
  /**
  * Code is based upon the code found in 
  * https://www.geeksforgeeks.org/bubble-sort/  .
  * @param compare Parameter used so I may be able to compare Objects from the data parameter
  * @param data This parameter is used so I may call up Objects to be sorted
  */

  /* (non-Javadoc)
 * @see edu.ics211.h02.SortableArray#bubbleSort(java.lang.Object[], java.util.Comparator)
 */
  @Override
public void bubbleSort(E[] data, Comparator<E> compare) {
    // TODO Auto-generated method stub
    compareCount = 0;
    swapCount = 0;
    int n = data.length;
    int k;
    for (int i = 0; i < n - 1; i++) {
      k = i;
      for (int j = i + 1; j < n ; j++) {

        if (compare.compare(data[j],data[k]) < 0) {
          swapCount++;
          swap(j, k, data);
        }
      }
      compareCount++;
    }
    
  }
  
  /**
  * I made a swap method based on the code in 
  * 'Data Structures: Abstraction and Design Using Java' Textbook by  Elliot B. Koffman.' .
  * @param i The j parameter is also an integer mainly taken from 
  *     either the for loop or an integer created to determine the position in an array
  * @param j The j parameter is also an integer mainly taken from either the for loop or an integer 
  *     created to determine the position in an array
  * @param data Data takes in generic type for the sake of swapping
  */
  
  public void swap(int i, int j, E[] data) {
    E temp;
    temp =  data[i];
    data[i] = data[j];
    data[j] = temp;
  }
  /**
  * The basis of this whole code comes from 
  * Listing 8.1 within
  * 'Data Structures: Abstraction and Design Using Java' Textbook by  Elliot B. Koffman.
  *  Variation and considerations are taken on https://www.geeksforgeeks.org/selection-sort/ .
  * Inserts the selectionSort method and algorithm.
  * @param compare Parameter used so I may be able to compare Objects from the data parameter
  * @param data This parameter is used so I may call up Objects to be sorted
  */

  /* (non-Javadoc)
 * @see edu.ics211.h02.SortableArray#selectionSort(java.lang.Object[], java.util.Comparator)
 */
  @Override
public void selectionSort(E[] data, Comparator<E> compare) {
    // TODO Auto-generated method stub
    compareCount = 0;
    swapCount = 0;
    int n = data.length;
    for (int fill = 0; fill < n - 1;fill++) {
      int posMin = fill;
      for (int next = fill + 1; next < n ;next++) {
        this.compareCount++;
        if (compare.compare(data[next],data[posMin]) < 0) {
          posMin = next;
          swapCount++;
        }
      } 
      swap(posMin, fill, data);
    }
  }
  /**
 * The purpose is to actually count the number of swapping done within a sort.
 * @return
 */
  
  @Override
  public int getNumberOfSwaps() {
    // TODO Auto-generated method stub
    return swapCount;
  }
  
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  
  /* (non-Javadoc)
 * @see edu.ics211.h02.SortableArray#getNumberOfComparisons()
 */
  @Override
  public int getNumberOfComparisons() {
    // TODO Auto-generated method stub
    return compareCount;
  }
  /**
 * For the purpose of looking and measuring the time of the sorts. 
 * Taken from lecture last Wednesday.
 * @return startTime-System.nanoTime() This is 
 */

  /* (non-Javadoc)
 * @see edu.ics211.h02.SortableArray#getSortTime()
 */
  @Override
public double getSortTime() {
    // TODO Auto-generated method stub
    /** Meant for checking the first part of time.**/ 
    long startTime = System.nanoTime();
    
    return System.nanoTime() - startTime;
  }

}

