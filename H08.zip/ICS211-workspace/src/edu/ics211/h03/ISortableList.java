package edu.ics211.h03;

import java.util.Comparator;
/**
 * This is the interface in the assignment page that is used for the sake
 * of SortableList and SortableBeerList.
 * @author Marty Joshua Apilado
 *
 * @param <E> This is any object that may be within an established list.
 */

public interface ISortableList<E> {
  /**
  * Here we have a method that is meant to sort by means of insertions.
  * Code based off of https://www.geeksforgeeks.org/insertion-sort/   
  * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
  *     sorting.
  */
  void insertionSort(Comparator<E> compare);

  /**
  * Code is based upon the code found in 
 * https://www.geeksforgeeks.org/bubble-sort/  .
 * Here we have a method that is meant to sort by means of comparing and switching objects 
 *   side by side based on comparison.
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  
  void bubbleSort(Comparator<E> compare);
  /**
 * Here we have a method that is meant to sort by means of comparing and switching objects 
 *   side by side based on comparison.
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  
  void selectionSort(Comparator<E> compare);
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  
  int getNumberOfSwaps();
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  
  int getNumberOfComparisons();
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  
  double getSortTime();
}