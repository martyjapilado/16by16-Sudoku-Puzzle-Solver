package edu.ics211.h05;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * The creation of a Circular Doubly Linked List class to stare items in.
 * 
 * @author Marty Joshua Apilado
 * @param <E>
 *          This means any other type of variable can go here.
 *
 */
public class CircularDoublyLinkedList<E> implements IList211<E>, Iterable<E> {

  /**
   * This is the DLinkedNode meant for implementation here. I took my previous work and changed
   * DLinkedNode to Node.
   * 
   * @author Marty Joshua Apilado
   *
   */

  private class Node {
    E item;
    Node next;
    Node prev;

    public Node(E item, Node next, Node prev) {
      this.item = item;
      this.next = next;
      this.prev = prev;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    /**
     * Based off of Dr.Moore's lecture.
     * 
     * @return Node [ " + item + " , " + next + " , " + prev + " ] returns a String of node
     */
    public String toString() {
      return "Node [ " + item + " , " + next + " , " + prev + " ]";
    }

  }

  /** Keep track of whatever is at the head. **/
  private Node head;
  /** Keep track of whatever is at the tail. **/
  @SuppressWarnings("unused")
  private Node tail;
  /** Set up the size of the List, which grows as more generic type objects are added. **/
  private int size = 0;

  /**
   * Creates a CircularDoublyLinkedList based off the array inserted in parameters.
   * 
   * @param item
   *          - The array of items that is created within the list.
   */
  public CircularDoublyLinkedList(E[] item) {
    for (E i : item) {
      this.add(i);
    }
    head.prev = tail;
    tail.next = head;
    head.item = this.get(0);
    tail.item = this.head.prev.item;

  }

  /**
   * Sets up the CircularDoublyLinkedList just in case.
   */

  public CircularDoublyLinkedList() {
    this.head = null;
    this.tail = null;

  }

  /**
   * Based off of lab exercise. This is an Array List Iterator meant to try out iterators.
   * 
   * @author Marty Joshua Apilado
   *
   */
  private class CListIterator implements Iterator<E>, ListIterator<E> {

    /** A number to check the position of the next value. **/
    private int nextIndex;

    /** An iterator to check for the next item on the list. **/
    private E nextItem = null;

    /** A number to check the position of the previous value. **/
    private int prevIndex;

    /**
     * Keep track of current Item returned.
     */
    private E currentItem;

    /** An iterator to check for the previous item on the list. **/
    private E prevItem = null;

    /**
     * Sets up the iterator, with prevIndex and nextIndex. Taken from Lab Slides.
     */
    public CListIterator() {
      this.nextIndex = 0;
      this.prevIndex = size - 1;
    }

    /**
     * Checks if the next item is not or does have null, if it does, it returns false, otherwise
     * true.
     * 
     * @return size > 0 Just checks if there is anything at all.
     */
    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#hasNext()
     */
    @Override
    public boolean hasNext() {
      // TODO Auto-generated method stub
      return size > 0;
    }

    /**
     * Provides the next value. Based off Lab Slides.
     * 
     * @return retVal The value that is next.
     */
    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#next()
     */
    @Override
    public E next() {
      // TODO Auto-generated method stub
      /*
       * if (nextItem == tail.item) { prevIndex = nextIndex; nextIndex = 0; tail.next.item =
       * head.item; } else if (nextItem == head.item) { prevIndex = 0; tail.next.item = head.item; }
       */
      /*
       * if (nextIndex == size) { this.nextItem = get(nextIndex - 1); nextIndex = 0; prevIndex++; }
       * else if (prevIndex == size) { this.nextItem = get(nextIndex); prevIndex = 0; nextIndex++; }
       * else { this.nextItem = get(nextIndex); prevIndex++; nextIndex++; }
       */
      /*
       * this.nextItem = get(nextIndex); nextIndex++; prevIndex++; return this.nextItem;
       */
      if (hasNext()) {
        
        this.nextItem = get(nextIndex);
        currentItem = this.nextItem;        
        prevIndex = (prevIndex + 1) % size;
        nextIndex = (nextIndex + 1) % size;
        return currentItem;
      }
      throw new NoSuchElementException();
    }

    /**
     * In the similar case to hasNext, checks if there is a previous item, otherwise returns false.
     * 
     * @return size > 0 Just checks if there is anything at all.
     */
    public boolean hasPrevious() {
      // TODO Auto-generated method stub
      return size > 0;
    }

    /**
     * Returns next Index. Just in case.
     * 
     * @return nextIndex - Whatever is the current index that the next item is at.
     */
    public int nextIndex() {
      // TODO Auto-generated method stub
      return nextIndex;
    }

    /**
     * Returns whatever the previous item at index is.
     * 
     * @return currentItem The previousItem Also throws new NoSuchElementException if there is
     *         nothing at previous
     */
    @Override
    public E previous() {
      // TODO Auto-generated method stub
      if (hasPrevious()) {
        if (nextIndex < 0) {
          nextIndex = size - 1;
        }
        if (prevIndex < 0) {
          prevIndex = size - 1;
        }
        this.prevItem = get(prevIndex);
        currentItem = this.prevItem;
        prevIndex = (prevIndex - 1);
        nextIndex = (nextIndex - 1);
        return currentItem;
      } 
      throw new NoSuchElementException();
      
    }

    /**
     * Removes last iteration called. In this case it's whatever was the currentItem index.
     * Tried to think of something at the spot, TA Branden helped at some parts.
     */

    /*
     * (non-Javadoc)
     * 
     * @see java.util.Iterator#remove()
     */
    @Override
    public void remove() {
      // TODO Auto-generated method stub
      if (currentItem == head) {
        // E removed = previous();
        CircularDoublyLinkedList.this.remove(0);
        size--;
        prevIndex = size - 1;
        nextIndex = 0;
      } else if (currentItem == tail) {
        // E removed = previous();
        CircularDoublyLinkedList.this.remove(size - 1);
        size--;
        prevIndex = size - 1;
        nextIndex = 0;
      } else if (currentItem != null && currentItem == this.nextItem) {
        // E removed = this.prevItem;
        
        CircularDoublyLinkedList.this.remove(this.nextIndex);
        size--;
        nextIndex--;
        if (nextIndex < 0) {
          nextIndex = size - 1;
        }
      } else if (currentItem != null && currentItem == this.prevItem) {
        // E removed = this.prevItem;
        CircularDoublyLinkedList.this.remove(this.prevIndex);
        nextIndex--;
        if (nextIndex < 0) {
          nextIndex = size - 1;
        }
        size--;
      } else {
        throw new IllegalStateException();
      }

    }

    /**
     * Is supposed to point out what ever is the previousIndex.
     * 
     * @return prevIndex Whatever the current prevIndex is according to the Iterator class.
     */

    @Override
    public int previousIndex() {
      // TODO Auto-generated method stub
      return prevIndex;
    }

    @Override
    public void set(E e) {
      // TODO Auto-generated method stub

    }

    @Override
    public void add(E arg0) {
      // TODO Auto-generated method stub

    }

  }

  /**
   * The creation and return of the iterator.
   * 
   * @return new ClistIterator() - it is whatever the iterator.
   */
  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Iterable#iterator()
   */
  @Override
  public Iterator<E> iterator() {
    return new CListIterator();
  }

  /**
   * based off of 'Linked List Screencast by Dr.Moore. Grabs whatever is within the parameters of
   * index, just in case we want that.
   * 
   * @param index
   *          This is pretty much the position of the object in the list
   * @return temp.item simply return the object depending on the position of the list
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.h03.IList211#get(int)
   */

  @Override
  public E get(int index) {
    // TODO Auto-generated method stub
    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    Node temp = head;
    for (int i = 0; i < index; i++) {
      temp = temp.next;
    }
    return temp.item;
  }

  /**
   * Sets a object based on index to an element. based off of 'Linked List Screencast by Dr.Moore.
   * 
   * @param index
   *          This is the index of the object to place.
   * @param element
   *          Whatever the element is, it ends up replacing whatever other element is there.
   * @returns retVal retVal is whatever the data is based off of index/position in the list.
   */
  @SuppressWarnings("unchecked")
  @Override
  public E set(int index, Object element) {
    // TODO Auto-generated method stub

    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    Node temp = head;
    for (int i = 0; i < index; i++) {
      temp = temp.next;
    }

    E retVal = temp.item;
    temp.item = (E) element;
    return retVal;
  }

  /**
   * Returns the number of the position that the object was from. Code based off of 'Linked List
   * Screencast by Dr.Moore.
   * 
   * @param obj
   *          Finds the object to read the object from.
   * @return i,-1 Returns i if null. Returns whatever is j if there is something based off the
   *         object. Returns -1 If there's just nothing there based off the list.
   */
  @Override
  public int indexOf(Object obj) {
    // TODO Auto-generated method stub
    Node temp = head;
    for (int i = 0; i < size; i++) {
      if (temp.item.equals(obj)) {
        return i;
      }
      temp = temp.next;
    }
    return -1;
  }

  /**
   * Gives the current size of the object.
   * 
   * @return size - The amount of objects in the list.
   */

  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.h05.IList211#size()
   */

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return size;
  }

  /**
   * Adds element to end of the list. Based off of Screencast by Dr. Moore.
   * 
   * @param e
   *          Element to add at the end.
   * @return true Returns trues if added through the use of the other add method.
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.h05.IList211#add(java.lang.Object)
   */
  @Override
  public boolean add(E e) {
    // TODO Auto-generated method stub
    add(size, e);
    return true;
  }

  /**
   * Adds element to the set index. Based off of Data Structures textbook by Koffman.
   * 
   * @param index
   *          - Where the object is placed within the list.
   * @param element
   *          - The object that is placed within the list.
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.h05.IList211#add(int, java.lang.Object)
   */
  @Override
  public void add(int index, E element) {
    // TODO Auto-generated method stub
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException(Integer.toString(index));
    } else if (index == 0) {
      head = new Node(element, head, null);
      size++;
    } else if (index == size) {
      Node temp = head;
      for (int i = 1; i < index; i++) {
        temp = temp.next;
      }
      temp.next = new Node(element, head, temp);
      tail = temp.next;
      size++;
    } else {
      Node temp = head;
      for (int i = 1; i < index; i++) {
        temp = temp.next;
      }
      temp.next = new Node(element, temp.next, null);
      size++;
    }
  }

  /**
   * Removes whatever object is in the position based off of the index. From Doctor Moore's
   * screencast
   * 
   * @param index
   *          This determines the position of the object to remove.
   * @return removed Simply a return value that is used (mostly I see it as a placeholder to give of
   *         what I want to remove)
   */
  /*
   * (non-Javadoc)
   * 
   * @see edu.ics211.h05.IList211#remove(int)
   */
  @Override
  public E remove(int index) {
    // TODO Auto-generated method stub
    /** Create a temporary generic type object variable to store whatever inside of it. **/
    if (index < 0 || index >= size) {
      throw new IndexOutOfBoundsException(index);
    }
    if (index == 0) {
      E oldVal = head.item;
      head = head.next;
      size--;
      return oldVal;
    } else {
      Node temp = head;
      for (int i = 0; i < index - 1; i++) {
        temp = temp.next;
      }
      E removed = temp.next.item;
      temp.next = temp.next.next;
      size--;
      return removed;
    }
  }

}
