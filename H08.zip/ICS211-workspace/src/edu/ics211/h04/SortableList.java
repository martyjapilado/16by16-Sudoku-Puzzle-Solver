package edu.ics211.h04;

import java.util.Comparator;




/**
 * Here is where the methods are made for the purpose of creating a List.
 * The kind of List that is capable of being sorted.
 * NEW H04 COMMENT: Now implementing double list
 * Some of the code based off of page 71-73 on 'Data Structures' by Elliot B. Koffman.
 * @author Marty Joshua Apilado
 *
 * @param <E> This is any sort of generic type that will be used in the list.
 */

public class SortableList<E> implements IList211<E>,ISortableList<E> {
  /**
   * This is the DLinkedNode meant for implementation here.
   * @author Marty Joshua
   *
   */
  
  private class DLinkedNode {
    E item;
    DLinkedNode next;
    DLinkedNode prev;

    public DLinkedNode(E item, DLinkedNode next, DLinkedNode prev) {
      this.item = item;
      this.next = next;
      this.prev = prev;
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    /**
     * Based off of Dr.Moore's lecture.
     * @return DLinkedNode [ " + item +  " , " + next + " , " + prev + " ] returns a String of node
     */
    public String toString() {
      return "DLinkedNode [ " + item +  " , " + next + " , " + prev + " ]" ;
    }


  }
  
  /** Keep track of whatever is at the head. **/
  private DLinkedNode head;
  /** Keep track of whatever is at the tail. **/
  @SuppressWarnings("unused")
  private DLinkedNode tail;
  /** Set up the size of the List, which grows as more generic type objects are added. **/
  private int size = 0;
  /** Counts number of swaps in a sort.**/
  int swapCount = 0;
  /** Counts number of comparisons inside of sort. **/
  int compareCount = 0;
  /**The time of when the sort begins. **/
  private long startTime = System.nanoTime();
  /**The measure of time of the entire sort. **/
  private long fullTime;
  
  /**
   * This is a constructor meant to establish the actual list when called upon.
   * Based off of https://stackoverflow.com/questions/4066729/creating-a-linkedlist-class-from-scratch
   */
  
  SortableList() {
    this.head = null;
    this.size = 0;
    this.tail = null;
  }
  /**
 * Here we have a method that is meant to sort by means of insertions.
 * Code based off of https://www.geeksforgeeks.org/insertion-sort/   
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  /*You should compare the values within the nodes, not the nodes themselves.  
   * If you are comparing the values at i and j for example, 
   * how would you get the values at i and j from the list?
   * As for the NullPointerException, that probably 
   * indicates that the nodes are not being linked together correctly; 
   * double check the add methods and compare them to what is in the lecture videos.(non-Javadoc)
   * -Note I kept from Branden regarding sorts
   * @see edu.ics211.h04.ISortableList#insertionSort(java.util.Comparator)
   */
  /**
 * Here we have a method that is meant to sort by means of insertions.
 * Code based off of https://www.geeksforgeeks.org/insertion-sort/   
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */
  
  public void insertionSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    compareCount = 0;
    swapCount = 0;
    for (int i = 1; i < size; i++) {
      E p = this.get(i);
      int j = i - 1;
      while (j >= 0 && compare.compare(p, this.get(j)) < 0) {
        this.set(j + 1, this.get(j));
        j = j - 1;
      }
      this.set(j + 1, p);
    }
    fullTime = System.nanoTime() - startTime;
  }
  /**
 * Here we have a method that is meant to sort by means of comparing and switching objects 
 *   side by side based on comparison.
 * Code from https://www.geeksforgeeks.org/bubble-sort/.
 * Got help from Colby.
 * @param compare Is meant to use as a means to compare generic types/objects for the sake of 
 *     sorting.
 */

  @Override
  public void bubbleSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    int n = size;
    compareCount = 0;
    swapCount = 0;
    for (int i = 0; i < n - 1; i++) {
      for (int j = 0; j < n - i - 1; j++) {
        this.compareCount++;
        if (compare.compare(this.get(j), this.get(j + 1)) < 0) {
          E temp;
          temp = this.get(j);
          this.set(j, this.get(j + 1));
          this.set(j + 1, temp);
          ++swapCount;
        }
      }
    }
    fullTime = System.nanoTime() - startTime;
  }

  /**
  * The basis of this whole code comes from 
  * Listing 8.1 within
  * 'Data Structures: Abstraction and Design Using Java' Textbook by  Elliot B. Koffman.
  *  Variation and considerations are taken on https://www.geeksforgeeks.org/selection-sort/ .
  * Inserts the selectionSort method and algorithm.
  * Got help by Colby on the sorts.
  * @param compare Parameter used so I may be able to compare Objects from the data parameter
  */
  
  /* (non-Javadoc)
 * @see edu.ics211.h03.ISortableList#selectionSort(java.util.Comparator)
 */
  @Override
  public void selectionSort(Comparator<E> compare) {
    // TODO Auto-generated method stub
    startTime = System.nanoTime();
    compareCount = 0;
    swapCount = 0;
    int n = size;
    for (int fill = 0; fill < n - 1;fill++) {
      int posMin = fill;
      for (int next = fill + 1; next < n ;next++) {
        this.compareCount++;
        if (compare.compare(this.get(next),this.get(posMin)) < 0) {
          posMin = next;
        }
      } 
      E temp;
      temp = this.get(posMin);
      this.set(posMin, this.get(fill));
      this.set(fill, temp);
      swapCount++;
    }
    fullTime = System.nanoTime() - startTime;
  }
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getNumberOfSwaps()
  */
  
  @Override
  public int getNumberOfSwaps() {
    // TODO Auto-generated method stub
    return swapCount;
  }
  /**
 * So this simply returns the number of Comparisons in a sorting algorithm.
 * @return compareCount this simply returns the int for compare count that was gathered during a 
 *     sort.
 */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getNumberOfComparisons()
  */
  
  @Override
  public int getNumberOfComparisons() {
    // TODO Auto-generated method stub
    return compareCount;
  }

  /**
  * For the purpose of looking and measuring the time of the sorts. 
  * Taken from lecture last Wednesday.
  * @return fullTime This is to get whatever is to find the measured time of a recent sort
  */
  /* (non-Javadoc)
  * @see edu.ics211.h03.ISortableList#getSortTime()
  */

  @Override
  public double getSortTime() {
    // TODO Auto-generated method stub
    return fullTime;
  }
  
  /**
   * based off of 'Linked List Screencast by Dr.Moore.
   * Grabs whatever is within the parameters of index, just in case we want that.
   * @param index This is pretty much the position of the object in the list
   * @return temp.item simply return the object depending on the position of the list
   */
  /* (non-Javadoc)
   * @see edu.ics211.h03.IList211#get(int)
  */

  @Override
  public E get(int index) {
    // TODO Auto-generated method stub
    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    DLinkedNode temp = head;
    for (int i = 0; i < index; i++) {
      temp = temp.next;     
    }
    return temp.item;
  }

  /**
   * Sets a object based on index to an element.
   * based off of 'Linked List Screencast by Dr.Moore.
   * @param index index
   * @param element Whatver the element is, it ends up replacing whatever other element is there.
   * @returns retVal retVal is whatever the data is based off of index/position in the list.
   */
  /* (non-Javadoc)
  * @see edu.ics211.h03.IList211#set(int, java.lang.Object)
  */
  @Override
  public E set(int index, E element) {
    // TODO Auto-generated method stub
    
    if (index < 0 || index >= size) {
      throw new ArrayIndexOutOfBoundsException(index);
    }
    DLinkedNode temp = head;
    for (int i = 0; i < index; i++) {
      temp = temp.next;
    }
    
    E retVal = temp.item;
    temp.item = element;
    return retVal;
  }
  
  /**
   * Returns the number of the position that the object was from.
   * Code based off of 'Linked List Screencast by Dr.Moore.
   * @param obj Finds the object to read the object from.
   * @return i,-1 Returns i if null. Returns whatever is j if there is 
   *     something based off the object. Returns -1 If there's just nothing there based 
   *     off the list.
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#indexOf(java.lang.Object)
 */
  @Override
  public int indexOf(Object obj) {
    // TODO Auto-generated method stub
    DLinkedNode temp = head;
    for (int i = 0; i < size; i++) {
      if (temp.item.equals(obj)) {
        return i;
      }
      temp = temp.next;
    }
    return -1;
  }

  /**
 * Returns number depending on how many objects are within the list.
 * @return size Whatever is the size is based off of the member variable here.
 */

  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#size()
 */

  @Override
  public int size() {
    // TODO Auto-generated method stub
    return size;
  }

  /**
   * Adds a whatever value to the end of the Array list.
   * based off of 'Linked List Screencast by Dr.Moore. Then I used the Data Structure
   * Textbook by Koffman.
   * @param e This would be whatever generic type value that is added to the end of the list
   * @return true Because nothing else would suffice.
   */

  @Override
  public boolean add(E e) {
    // TODO Auto-generated method stub
    /**    if (head == null) {
      head = new DLinkedNode(e,null,null);
    } else {
      DLinkedNode temp = head; 
      for (int i = 0; i < size - 1;i++) {
        temp = temp.next;
      }
      temp.next = new DLinkedNode(e,null,null);
    }
    size++;
    return true; **/
    /**tail.next = new DLinkedNode(e,null,tail);
    tail = tail.next;
    size++;
    return true;**/
    add(size,e);
    return true; 
  }
  /**
   * Add method but can now add it to the middle of the list rather than the last availabe
   * position.
   * Code based off of Linked List Screencast by Dr. Moore.
   * @param element Element that is going to be inserted to the code
   * @param index Index is the position that the object will be added to
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#add(int, java.lang.Object)
 */
  
  @Override
  public void add(int index, E element) {
    // TODO Auto-generated method stub
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException(Integer.toString(index));
    }
    if (index == 0) {
      head = new DLinkedNode(element,head, null);
      size++;
    } else {
      DLinkedNode temp = head;
      for (int i = 1; i < index;i++) {
        temp = temp.next;
      }
      temp.next = new DLinkedNode(element,temp.next,null);
      size++;
    } 

  }
 
  /**
 * This was taken from 'Data Structures' Textbook by Elliot B. Wolfgang' pg. 73
 * when I wanted an efficient way to actually copy over an array to a newer one 
 * when adding and increasing the capacity of an array.
 */
  

  /**
   * Removes whatever object is in the position based off of the index.
   * From Doctor Moore's screencast
   * @param index This determines the position of the object to remove.
   * @return removed Simply a return value that is used 
   *     (mostly I see it as a placeholder to give of
   *     what I want to remove)
   */
  /* (non-Javadoc)
 * @see edu.ics211.h03.IList211#remove(int)
 */
  @Override
  public E remove(int index) {
    // TODO Auto-generated method stub
    /** Create a temporary generic type object variable to store whatever inside of it.**/
    if (index < 0 || index >= size) {
      throw new IndexOutOfBoundsException(index);
    }
    if (index == 0) {
      E oldVal = head.item;
      head = head.next;
      size--;
      return oldVal;
    } else {
      DLinkedNode temp = head;
      for (int i = 0; i < index - 1; i++) {
        temp = temp.next;
      }
      E removed = temp.next.item;
      temp.next = temp.next.next;
      size--;
      return removed;
    }
  }
  

}
