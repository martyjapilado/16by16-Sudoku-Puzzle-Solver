package edu.ics211.h05;

import static org.junit.Assert.assertEquals;

import edu.ics211.h01.Beer;
import edu.ics211.h01.IBrewery;
import edu.ics211.h01.ManoaBrewing;

import java.util.LinkedList;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;


/**
 * Tests out the class of my Josephus Beer Flight class.
 * @author Marty Joshua Apilado
 *
 */
public class JosephusBeerFlightTestStudent {
  private ManoaBrewing brewery;
  private Beer[] beers = new Beer[5];
  
  /**
   * Sets up an initialized instance of the flight test
   * based off of test on assignment page.
   * @throws Exception throws just in case
   */
  @Before
  public void initializes() throws Exception {
    brewery = ManoaBrewing.getInstance();
    for (int i = 0; i < beers.length; i++) {
      beers[i] = brewery.brewBeer("Beer" + i, randomBeerType());
    }
  }
  /**
   * Just tests to see if the length initializes is correct.
   */
  
  @Test
  public void testJosephusBeerFlight() {
    JosephusBeerFlight beer = new JosephusBeerFlight(beers);
    assertEquals(beer.beer.size(), 0);
  }

  /**
   * Based off of Original test code by Dr.Moore
   * Tests out certain cases of the tasteBeer method.
   * The way it works is that tasting happens once and based on that the 
   * get method is grabs whatever is there except the missing part of beer, 
   * which is in beers.
   */
  @Test
  public void testTasteBeers() {
    JosephusBeerFlight beer = new JosephusBeerFlight(beers);
    LinkedList<Beer> tasting = beer.tasteBeers(0, 1, true);
    assertEquals(tasting.get(0), beers[1]);
  }

  /**
   * BASED off of code in the other Josephus Beer Flight Test by Dr. Moore.
   * Returns a random beer type.
   * @return A random beer type.
   */
  private String randomBeerType() {
    Random r = new Random();
    int val = r.nextInt(3);
    switch (val) {
      case 0:
        return IBrewery.PILSNER;
      case 1:
        return IBrewery.BOHEMIAN_PILSNER;
      case 2:
        return IBrewery.INDIA_PALE_ALE;
      default:
        return IBrewery.INDIA_PALE_ALE;
    }
  }
}
